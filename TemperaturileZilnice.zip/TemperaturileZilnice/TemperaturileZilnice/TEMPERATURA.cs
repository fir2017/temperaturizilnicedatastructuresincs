﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TemperaturileZilnice
{
    public  class TEMPERATURA
    {
        public float TEMP;
        public string TIPGRADE;

        public TEMPERATURA(float temp, string tipgrade)
        {
            TEMP = temp;
            TIPGRADE = tipgrade;
        }
    }
}
