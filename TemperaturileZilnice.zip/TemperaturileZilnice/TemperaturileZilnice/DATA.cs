﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TemperaturileZilnice
{
    public class DATA
    {
        public int AN;
        public int LUNA;
        public int ZI;
   

    public DATA (int an, int luna , int zi)
    {
        AN = an;
        LUNA = luna;
        ZI = zi;
    } 
    }
}
